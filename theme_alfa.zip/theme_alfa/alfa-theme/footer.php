<?php
/**
 * The template for displaying the footer
 */

?>	
		<!-- Footer -->
		<footer class="py-5 bg-dark">
		  <section class="container-fluid" style="background:#23292b">
				<div class="row">
					<div class="container">
						<div class="col col-md-12 main-foot">
						  <div class="col-md-3 col-sm-3 foot">
							<div id="footer-sidebar1">
								<?php
									if(is_active_sidebar('footer-1')){
									dynamic_sidebar('footer-1');
								}
								?>
							</div>
						  </div>
							<div class="col-md-3 col-sm-3 foot">
								<div id="footer-sidebar2">
									<?php
									if(is_active_sidebar('footer-2')){
									dynamic_sidebar('footer-2');
									}
									?>
								</div>
							</div>
							<div class="col-md-3 col-sm-3 foot">
								<div id="footer-sidebar3">
									<?php
									if(is_active_sidebar('footer-3')){
									dynamic_sidebar('footer-3');
									}
									?>
								</div>
							</div>
							<div class="col-md-3 col-sm-3 foot" style="padding-bottom:40px;">
								<div id="footer-sidebar4">
									<?php
									if(is_active_sidebar('footer-4')){
									dynamic_sidebar('footer-4');
									}
									?>
								</div>
							</div>
						</div>
					</div>
				</div>
				
				<hr class="container">
					<div class="container">
					  <div style="float:left">
						<?php
							if(is_active_sidebar('copyrgt')){
							dynamic_sidebar('copyrgt');
							}
						?>
					  </div>
					  <div class="social-links class01-02" style="float:right">
						<?php
							if(is_active_sidebar('footer-social')){
							dynamic_sidebar('footer-social');
							}
						?>
					  </div>
					</div>
				</hr>
			</section>
			
		</footer>
		
		<!-- Bootstrap core JavaScript -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" crossorigin="anonymous"></script>
		
	</body>
 </html>
	  <?php wp_footer(); ?>
	</body>
</html>
