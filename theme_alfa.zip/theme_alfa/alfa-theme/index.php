<?php get_header(); ?>
			<?php echo get_post_meta($post->ID, 'Our_process', true); ?>
	
			<?php echo get_post_meta($post->ID, 'our_services', true); ?>
				
			<?php echo get_post_meta($post->ID, 'contact-info', true); ?>
			
			<?php echo get_post_meta($post->ID, 'Projects', true); ?>
			
			<?php echo get_post_meta($post->ID, 'Gallery', true); ?>
			
			<?php echo get_post_meta($post->ID, 'CTA', true); ?>
			
			<?php echo get_post_meta($post->ID, 'test', true); ?>
			
			<?php echo get_post_meta($post->ID, 'Pricing', true); ?>
			
			<?php echo get_post_meta($post->ID, 'Showcase_box', true); ?>
			
			<?php echo get_post_meta($post->ID, 'Client', true); ?>
			
		</main>

<?php get_footer(); ?>