<?php
/**
 * The template for displaying the footer
 */

?>	
		<!-- Footer -->
		<footer class="py-5 bg-dark">
		  <section class="container-fluid" style="background:#23292b">
				<div class="row">
					<div class="container">
						<div class="col col-md-12 main-foot">
							<div class="col-md-3 col-sm-3">
								<h4>Newsletter Signup</h4>
								<input type="E-mail" placeholder="&nbsp;Enter your E-mail" style="background: transparent;padding:5px;color:#fff;">
							</div>
							<div class="col-md-3 col-sm-3 foot">
								<h4>Useful Links</h4>
									<p style="color:#fff;">
										<i class="fas fa-arrow-right"><a class="nav-link" href="#" style="text-decoration:none;">&nbsp;&nbsp;About Us</a></i></p>
									<p style="color:#fff;">
										<i class="fas fa-arrow-right"><a class="nav-link" href="services.html" style="text-decoration:none;">&nbsp;&nbsp;Our Services</a></i></p>
									<p style="color:#fff;">
										<i class="fas fa-arrow-right"><a class="nav-link" href="about.html" style="text-decoration:none;">&nbsp;&nbsp;Testimonials</a></i></p>
									<p style="color:#fff;">
										<i class="fas fa-arrow-right"><a class="nav-link" href="contact.html" style="text-decoration:none;">&nbsp;&nbsp;Price</a></i></p>
									<p style="color:#fff;">
										<i class="fas fa-arrow-right"><a class="nav-link" href="contact.html" style="text-decoration:none;">&nbsp;&nbsp;Contact us</a></i></p>
							</div>
							<div class="col-md-3 col-sm-3 foot">
								<h4>Our Services</h4>
									<p style="color:#fff;">
										<i class="fas fa-arrow-right"><a class="nav-link" href="#" style="text-decoration:none;">&nbsp;&nbsp;Carpet Cleaning</a></i></p>
									<p style="color:#fff;">
										<i class="fas fa-arrow-right"><a class="nav-link" href="about.html" style="text-decoration:none;">&nbsp;&nbsp;Regular Cleaning</a></i></p>
									<p style="color:#fff;">
										<i class="fas fa-arrow-right"><a class="nav-link" href="services.html" style="text-decoration:none;">&nbsp;&nbsp;Gutter Cleaning</a></i></p>
									<p style="color:#fff;">
										<i class="fas fa-arrow-right"><a class="nav-link" href="contact.html" style="text-decoration:none;">&nbsp;&nbsp;Gardening</a></i></p>
									<p style="color:#fff;">
										<i class="fas fa-arrow-right"><a class="nav-link" href="contact.html" style="text-decoration:none;">&nbsp;&nbsp;Oven Cleaning Service</a></i></p>
							</div>
							<div class="col-md-3 col-sm-3 foot" style="padding-bottom:40px;">
								<h4>Office Details</h4>
								<div class="col">
									<li style="display:flex"><i class="fas fa-map-marker-alt" style="margin:0 5px; color:#eee;"></i>&emsp;<p style="color:#fff;">Lorem Ipsum</p></li>
									<li style="display:flex"><i class="fas fa-phone" style="margin:0 5px; color:#eee;"></i>&emsp;<p style="color:#fff;">Lorem Ipsum</p></li>
									<li style="display:flex"><i class="fas fa-envelope" style="margin:0 5px; color:#eee;"></i>&emsp;<p style="color:#fff;">Lorem Ipsum</p></li>
									<li style="display:flex"><i class="fas fa-mobile-alt" style="margin:0 5px; color:#eee;"></i>&emsp;<p style="color:#fff;">Lorem Ipsum</p></li>
									<li style="display:flex"><i class="fas fa-chevron-circle-right" style="margin:0 5px; color:#eee;"></i>&emsp;<p style="color:#fff;">Lorem Ipsum</p></li>
								</div>
							</div>
						</div>
					</div>
				</div>
				<hr class="container">
					<div class="container">
					  <div style="float:left">
						<p class="copyrt" style="color:#eee">Copyright © Your Website 2018</p>
					  </div>
					  <div class="social-links class01-02" style="float:right">
						<a href="#" class="twitter"><i class="fab fa-facebook-f"></i></a>
						<a href="#" class="google-plus"><i class="fab fa-google-plus"></i></a>
						<a href="#" class="facebook"><i class="fab fa-twitter"></i></a>
						<a href="#" class="youtube"><i class="fab fa-youtube"></i></a>
						<a href="#" class="linkedin"><i class="fab fa-linkedin"></i></a>
					  </div>
					</div>
				</hr>
			</section>
			
			<div id="footer-sidebar" class="secondary">
				<div id="footer-sidebar1">
					<?php
					if(is_active_sidebar('footer-sidebar-1')){
					dynamic_sidebar('footer-sidebar-1');
					}
					?>
				</div>
				<div id="footer-sidebar2">
					<?php
					if(is_active_sidebar('footer-sidebar-2')){
					dynamic_sidebar('footer-sidebar-2');
					}
					?>
				</div>
				<div id="footer-sidebar3">
					<?php
					if(is_active_sidebar('footer-sidebar-3')){
					dynamic_sidebar('footer-sidebar-3');
					}
					?>
				</div>
			</div>
			
		</footer>
		
		<!-- Bootstrap core JavaScript -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" crossorigin="anonymous"></script>
		
	</body>
 </html>
	  <?php wp_footer(); ?>
	</body>
</html>
