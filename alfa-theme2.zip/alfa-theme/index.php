<?php get_header(); ?>
			<section id="section_01" class="container-fluid">
				<div class="container Process">
					<div class="row" style="text-align:center; margin:auto;">
					  <div class="col-lg-12 txt_center">
						<h3 class="section-heading">Our Process</h3>
					  </div>
					</div>
				</div>
				
				<div class="container Process">
					<div class="row">
					  <div class=" col-md-3 col-sm-6">
						<div class="service-box">
							<img src="<?php bloginfo('template_directory'); ?> /img/icon1.png" class="img-responsive center-block" alt="img_01"><br> 
							<p class="" style="color:#a0a2a5">
								It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. 
							</p>
						</div>
					  </div>
					  <div class=" col-md-3 col-sm-6">
						<div class="service-box">
							<img src="<?php bloginfo('template_directory'); ?> /img/icon2.png" class="img-responsive center-block" alt="img_02"><br>
							<p class="" style="color:#a0a2a5">
								It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. 
							</p>
						</div>
					  </div>
					  <div class=" col-md-3 col-sm-6">
						<div class="service-box">
							<img src="<?php bloginfo('template_directory'); ?> /img/icon3.png" class="img-responsive center-block" alt="img_03"><br>
							<p class="" style="color:#a0a2a5">
								It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. 
							</p>
						</div>
					  </div>
					  <div class=" col-md-3 col-sm-6">
						<div class="service-box">
							<img src="<?php bloginfo('template_directory'); ?> /img/icon4.png" class="img-responsive center-block" alt="img_04"><br>
							<p class="" style="color:#a0a2a5">
								It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. 
							</p>
						</div>
					  </div>
					</div>
				</div>
			</section> <!-- our process is complited -->
	
			<section id="section_02" class="container services">
				<div class="row">
					<h3 class="service"> Our Services </h3>
					<div class="col-md-12 service_div">	
						<div class="col-md-3 col-sm-6">
							<div class="col service_img">
								<a href=""><img src="<?php bloginfo('template_directory'); ?> /img/3.jpg" alt="image"/></a>
							</div>
							<div class="col i_title">
								<div class="col-sm-3"><a href="#"><img src="<?php bloginfo('template_directory'); ?> /img/carpet.png" alt="image"></a></div>
								<div class="col-sm-9"><h4>Carpet Cleaning</h4></div>
							</div><div class="clearfix"></div>
							<p>	It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </p>
							<h5><a href="#">Read more&nbsp;<i class="fas fa-arrow-right"></i></a></h5>
						</div> 
						<div class="col-md-3 col-sm-6">
							<div class="col service_img">
								<a href=""><img src="<?php bloginfo('template_directory'); ?> /img/4.jpg" alt="image"/></a>
							</div>
							<div class="col i_title">
								<div class="col-sm-3"><a href="#"><img src="<?php bloginfo('template_directory'); ?> /img/reg-clean.png" alt="image"></a></div>
								<div class="col-sm-9"><h4>Regular Cleaning</h4></div>
							</div><div class="clearfix"></div>
							<p>	It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </p>
							<h5><a href="#">Read more&nbsp;<i class="fas fa-arrow-right"></i></a></h5>
						</div> 
						<div class="col-md-3 col-sm-6">
							<div class="col service_img">
								<a href=""><img src="<?php bloginfo('template_directory'); ?> /img/5.jpg" alt="image"/></a>
							</div>
							<div class="col i_title">
								<div class="col-sm-3"><a href="#"><img src="<?php bloginfo('template_directory'); ?> /img/reg-clean2.png" alt="image"></a></div>
								<div class="col-sm-9"><h4>Gutter Cleaning</h4></div>
							</div><div class="clearfix"></div>
							<p>	It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </p>
							<h5><a href="#">Read more&nbsp;<i class="fas fa-arrow-right"></i></a></h5>
						</div> 
						<div class="col-md-3 col-sm-6">
							<div class="col service_img">
								<a href=""><img src="<?php bloginfo('template_directory'); ?> /img/6.jpg" alt="image"/"></a>
							</div>
							<div class="col i_title">
								<div class="col-sm-3"><a href="#"><img src="<?php bloginfo('template_directory'); ?> /img/garden.png" alt="image"></a></div>
								<div class="col-sm-9"><h4>Gardening</h4></div>
							</div><div class="clearfix"></div>
							<p>	It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </p>
							<h5><a href="#">Read more&nbsp;<i class="fas fa-arrow-right"></i></a></h5>
						</div> 
					</div>
					
					<div class="col-md-12 service_div">
						<div class="col-md-3 col-sm-6">
							<div class="col service_img">
								<a href=""><img src="<?php bloginfo('template_directory'); ?> /img/7.jpg" alt="image"/></a>
							</div>
							<div class="col i_title">
								<div class="col-sm-3"><a href="#"><img src="<?php bloginfo('template_directory'); ?> /img/oven.png" alt="image"></a></div>
								<div class="col-sm-9"><h4>Oven Cleaning Services</h4></div>
							</div><div class="clearfix"></div>
							<p>	It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </p>
							<h5><a href="#">Read more&nbsp;<i class="fas fa-arrow-right"></i></a></h5>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="col service_img">
								<a href=""><img src="<?php bloginfo('template_directory'); ?> /img/8.jpg" alt="image"/></a>
							</div>
							<div class="col i_title">
								<div class="col-sm-3"><a href="#"><img src="<?php bloginfo('template_directory'); ?> /img/pest.png" alt="image"></a></div>
								<div class="col-sm-9"><h4>Pest Control Services</h4></div>
							</div><div class="clearfix"></div>
							<p>	It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </p>
							<h5><a href="#">Read more&nbsp;<i class="fas fa-arrow-right"></i></a></h5>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="col service_img">
								<a href=""><img src="<?php bloginfo('template_directory'); ?> /img/9.jpg" alt="image"/></a>
							</div>
							<div class="col i_title">
								<div class="col-sm-3"><a href="#"><img src="<?php bloginfo('template_directory'); ?> /img/assembl.png" alt="image"></a></div>
								<div class="col-sm-9"><h4>Furniture Assemble</h4></div>
							</div><div class="clearfix"></div>
							<p>	It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </p>
							<h5><a href="#">Read more&nbsp;<i class="fas fa-arrow-right"></i></a></h5>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="col service_img">
								<a href=""><img src="<?php bloginfo('template_directory'); ?> /img/10.jpg" alt="image"/></a>
							</div>
							<div class="col i_title">
								<div class="col-sm-3"><a href="#"><img src="<?php bloginfo('template_directory'); ?> /img/paint.png" alt="image"></a></div>
								<div class="col-sm-9"><h4>Painting & Decorating</h4></div>
							</div><div class="clearfix"></div>
							<p>	It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </p>
							<h5><a href="#">Read more&nbsp;<i class="fas fa-arrow-right"></i></a></h5>
						</div>
					</div>
				</div>
			</section>
				
			<section id="section_03" class="container-fluid">
				<div class="container">
					<div class="col-md-8 aboutus">
						<div class="about_head">
							<h3>About us</h3><br><br>
							<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </p>
							<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </p>
						</div>
						<h3>Call us for fast booking</h3>
						<p>Ph.:&nbsp;+919852142312</p><br>
						<button type="submit">Read More</button>
					</div>
					<div class="col-md-4 aboutus" style="top: -50px;">
						<h5>Get In Touch</h5>
						<div class="form-component input_box">
							<div class="input_icon">
								<input type="text" placeholder="&nbsp;Name">
								<i class="fa fa-user"></i>
							</div>
							<div class="input_icon">
								<input type="text" placeholder="&nbsp;Phone">
								<i class="fa fa-phone"></i>
							</div>
							<div class="input_icon">
								<input type="E-mail" placeholder="&nbsp;Email">
								<i class="fa fa-envelope"></i>
							</div>
							<div class="input_icon">
								<input type="address" placeholder="&nbsp;Address">
								<i class="fa fa-map-marker-alt"></i>
							</div>
							<div class="input_icon">	
								<input type="text" placeholder="&nbsp;mm/dd" style="width:110px;">
								<i class="fa fa-calendar-alt" style="top:0px"></i>									
								<input type="text" placeholder="&nbsp;Time" style="width:110px;">
								<i class="fa fa-calendar-alt" style="top:0px"></i>
							</div>
							<div class="input_icon msg">
								<textarea rows="4" cols="32" placeholder="&nbsp;Massage"></textarea>
								<i class="fa fa-envelope" style="top: -75px;"></i>
							</div>
							<button type="submit" style="margin: 5px 0;">make an appoinment</button>
						</div>
					</div>
				</div>
			</section>
			
			<section id="section_04" class="container-fluid Projects">
				<div class="container">
					<h3> Our Projects</h3>
					<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
				</div>
			</section>
			
			<section id="section_05" class="container-fluid Gallery">
				<div class="col-md-12 img-grid">
					<div class="col-md-3 col-sm-6 col-xs-6">
						<a href=""><img src="<?php bloginfo('template_directory'); ?> /img/3.jpg" alt="image" /></a>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-6 abc">
						<a href=""><img src="<?php bloginfo('template_directory'); ?> /img/2.jpeg" alt="image" /></a>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-6 ">
						<a href=""><img src="<?php bloginfo('template_directory'); ?> /img/5.jpg" alt="image" /></a>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-6 ">
						<a href=""><img src="<?php bloginfo('template_directory'); ?> /img/6.jpg" alt="image" /></a>
					</div>
				</div>
				<div class="col-md-12 img-grid">
					<div class="col-md-3 col-sm-6 col-xs-6 ">
						<a href=""><img src="<?php bloginfo('template_directory'); ?>/img/7.jpg" alt="image" /></a>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-6 ">
						<a href=""><img src="<?php bloginfo('template_directory'); ?>/img/8.jpg" alt="image" /></a>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-6 ">
						<a href=""><img src="<?php bloginfo('template_directory'); ?>/img/9.jpg" alt="image" /></a>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-6 ">
						<a href=""><img src="<?php bloginfo('template_directory'); ?>/img/10.jpg" alt="image" /></a>
					</div>
				</div>
			</section>
			
			<section id="section_06" class="container-fluid CTA">
				<div class="container">
					<h3> Save Money With Discount Special and <br> <span>Home Service Junction</span> Coupons</h3>
					<button type="submit">Request Services</button>
				</div>
			</section>
			
			<section id="section_07" class="container services">
				<div class="row" style="display:block;">
					<h3> Why Our Customers Choose Us? </h3>
					<div class="col-md-12">	
						<div class="col-md-4 ps_lft">
							<div class="row">
								<h4>We Are Experts</h4><br>
								<p>	It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </p>
							</div>
							<div class="row">
								<h4>We Are Commited</h4><br>
								<p>	It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </p>
							</div>
						</div>
						<div class="col-md-4">
							<a href=""><img src="<?php bloginfo('template_directory'); ?> /img/11.jpg" alt="image" style="width:100%; height: 260 px" class="img-responsive"></a>
						</div>
						<div class="col-md-4 ps_rgt">
							<div class="row">
								<h4>We Are Complete</h4><br>
								<p>	It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </p>
							</div>
							<div class="row">
								<h4>We Are Driven</h4><br>
								<p>	It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </p>
							</div>
						</div>
					</div>
				</div>
			</section>
			
			<section id="section_08" class="container-fluid">
				<div class="container Pricing">
					<h3> Our Pricing </h3>
					<div class="col-md-12">
						<div class="col-md-3 col-sm-6">
							<h5 style="border-top-left-radius: 20px; border-top-right-radius: 20px;">Lorem Ipsum</h5>
							<div class="price_list">
								<p class="alt-01">Lorem Ipsum</p>
								<p class="alt-02">Lorem Ipsum</p>
								<p class="alt-01">Lorem Ipsum</p>
								<p class="alt-02">Lorem Ipsum</p>
								<p class="alt-01">Lorem Ipsum</p>
								<p class="alt-02">Lorem Ipsum</p>
								<button type="submit">READ MORE</button>
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<h5 style="border-top-left-radius: 20px; border-top-right-radius: 20px; background:#98bd2f;">Lorem Ipsum</h5>
							<div class="price_list">
								<p class="alt-01">Lorem Ipsum</p>
								<p class="alt-02">Lorem Ipsum</p>
								<p class="alt-01">Lorem Ipsum</p>
								<p class="alt-02">Lorem Ipsum</p>
								<p class="alt-01">Lorem Ipsum</p>
								<p class="alt-02">Lorem Ipsum</p>
								<button type="submit" style="background:#98bd2f;">READ MORE</button>
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<h5 style="border-top-left-radius: 20px; border-top-right-radius: 20px;">Lorem Ipsum</h5>
							<div class="price_list">
								<p class="alt-01">Lorem Ipsum</p>
								<p class="alt-02">Lorem Ipsum</p>
								<p class="alt-01">Lorem Ipsum</p>
								<p class="alt-02">Lorem Ipsum</p>
								<p class="alt-01">Lorem Ipsum</p>
								<p class="alt-02">Lorem Ipsum</p>
								<button type="submit">READ MORE</button>
							</div>
						</div>
						<div class="col-md-3 col-sm-6" style="padding-bottom:40px;">
							<h5 style="border-top-left-radius: 20px; border-top-right-radius: 20px;">Lorem Ipsum</h5>
							<div class="price_list">
								<p class="alt-01">Lorem Ipsum</p>
								<p class="alt-02">Lorem Ipsum</p>
								<p class="alt-01">Lorem Ipsum</p>
								<p class="alt-02">Lorem Ipsum</p>
								<p class="alt-01">Lorem Ipsum</p>
								<p class="alt-02">Lorem Ipsum</p>
								<button type="submit">READ MORE</button>
							</div>
						</div>
					</div>
				</div>
			</section> <!-- our process is complited -->
			
			<section id="section_09" class="container services Showcase_box">
				<div class="row">
					<h3> What They Said About Us </h3>
					<div class="col-md-12">	
						<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p><br>
						<div class="m-img" style="text-align:center;">
							<img src="<?php bloginfo('template_directory'); ?> /img/m-img.jpg">
						</div>
						<h4 style="text-align:center">Lorem Ipsum</h4>
						<h5 style="text-align:center">Manager & Senior Assistant</h5>
						<p><q>&nbsp;It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</q></p>
					</div>
				</div>
				
				<div id="myCarousel" class="carousel slide" data-ride="carousel">
					<!-- Indicators -->
					<ol class="carousel-indicators" style="top:0px;">
						<li data-target="#myCarousel" data-slide-to="0" class="active" style="border: 1px solid #678797; background:#d1d1d1; border-radius: 10px;"></li>
						<li data-target="#myCarousel" data-slide-to="1" class="active" style="border: 1px solid #678797; background:#01bdfb; border-radius: 10px;"></li>
						<li data-target="#myCarousel" data-slide-to="2" class="active" style="border: 1px solid #678797; background:#d1d1d1; border-radius: 10px;"></li>
					</ol>
				</div>
			</section>
			
			<section id="section_10" class="container-fluid services Client">
				<div class="row">
					<div class="container">
						<h3> Our Clients </h3>
						<div class="col col-md-12 Clients">	
							<div class=" col-sm-4 col-xs-4 col-md-2"><i class="fas fa-question"></i></div>
							<div class=" col-sm-4 col-xs-4 col-md-2"><i class="fas fa-question" style="color:#6b8734;"></i></div>
							<div class=" col-sm-4 col-xs-4 col-md-2"><i class="fas fa-question"></i></div>
							<div class=" col-sm-4 col-xs-4 col-md-2"><i class="fas fa-question"></i></div>
							<div class=" col-sm-4 col-xs-4 col-md-2"><i class="fas fa-question"></i></div>
							<div class=" col-sm-4 col-xs-4 col-md-2"><i class="fas fa-question"></i></div>
							
							<!-- Left and right controls -->
							<a class="left " href="#myCarousel" data-slide="prev" style="position: absolute;top: 0;bottom: 0; left: 0;width: 0%;font-size: 40px;color: #01bdfb;text-align: center;">
							  <span class="glyphicon glyphicon-chevron-left" style="top:15px"></span>
							</a>
							<a class="right" href="#myCarousel" data-slide="next" style="position: absolute;top: 0;bottom: 0; right: 0;font-size: 40px;color: #01bdfb;text-align: center;">
							  <span class="glyphicon glyphicon-chevron-right" style="top:15px"></span>
							</a>
						</div>
					</div>
				</div>
			</section>
			
		</main>

<?php get_footer(); ?>